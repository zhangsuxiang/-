function angles = calculate_fault_angles(strike, dip, sigma1_azimuth, sigma1_dip, sigma2_azimuth, sigma2_dip, sigma3_azimuth, sigma3_dip)
    % 计算断层法向量与应力场三个主应力轴之间的夹角
    % 输入:
    % strike: 断层面的走向（度）
    % dip: 断层面的倾角（度）
    % sigma1_azimuth: σ1的方位角（度）
    % sigma1_dip: σ1的倾角（度）
    % sigma2_azimuth: σ2的方位角（度）
    % sigma2_dip: σ2的倾角（度）
    % sigma3_azimuth: σ3的方位角（度）
    % sigma3_dip: σ3的倾角（度）
    % 输出:
    % angles: 与σ1, σ2, σ3的夹角数组（限定在0-90°之间）

    % 计算断层面的法向量
    n = fault_normal(strike, dip);

    % 将主应力轴方位角和倾角转换为单位向量
    sigma1 = stress_axis_vector(sigma1_azimuth, sigma1_dip);
    sigma2 = stress_axis_vector(sigma2_azimuth, sigma2_dip);
    sigma3 = stress_axis_vector(sigma3_azimuth, sigma3_dip);

    % 计算法向量与每个主应力轴的夹角
    angle1 = acosd(dot(n, sigma1) / (norm(n) * norm(sigma1))); % 与σ1的夹角
    angle2 = acosd(dot(n, sigma2) / (norm(n) * norm(sigma2))); % 与σ2的夹角
    angle3 = acosd(dot(n, sigma3) / (norm(n) * norm(sigma3))); % 与σ3的夹角

    % 将夹角限制在0-90度
    angles(1) = limit_angle_to_90(angle1);
    angles(2) = limit_angle_to_90(angle2);
    angles(3) = limit_angle_to_90(angle3);
end
