function n = fault_normal(strike, dip)
    % 计算断层面的法向量
    % 输入:
    % strike: 断层面的走向（度）
    % dip: 断层面的倾角（度）
    % 输出:
    % n: 断层面的法向量（单位向量，三维列向量）
    
    % 将角度转换为弧度
    strike_rad = deg2rad(strike);  % 走向转为弧度
    dip_rad = deg2rad(dip);        % 倾角转为弧度
    
    % 对于水平倾角为0°的情况，直接将法向量设置为Z轴方向
    if dip == 0
        n = [0; 0; 1];  % 水平断层法向量指向正Z轴
    else
        % 计算法向量
        n = [cos(dip_rad) * sin(strike_rad);  % x分量
             -cos(dip_rad) * cos(strike_rad); % y分量
             sin(dip_rad)];                   % z分量
    end
    
    % 确保法向量是三维列向量
    n = n(:);  % 强制转为列向量
end