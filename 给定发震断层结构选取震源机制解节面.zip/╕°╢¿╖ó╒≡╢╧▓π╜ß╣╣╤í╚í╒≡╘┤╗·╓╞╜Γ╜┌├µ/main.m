clear all;close all;clc;
% 震源机制解数据
data=load('test_data.txt');  %走向、倾角、滑动角

% 给定的发震断层结构
str = 224.92;  % 走向
dip = 82.41;  % 倾角


% 计算给定发震断层面的法向量
n_fault = fault_normal(str, dip);

% 初始化最小夹角和对应的节面参数
min_angle = Inf;
best_str2 = NaN;
best_dip2 = NaN;
best_rake2 = NaN;

% 用于存储最优节面（走向、倾角、滑动角）数据
best_node_plane = [];

% 遍历每个震源机制解
for i = 1:size(data, 1)
    % 获取每个震源机制解的参数
    str2 = data(i, 1);  % 第一个节面的走向
    dip2 = data(i, 2);  % 第一个节面的倾角
    rake2 = data(i, 3);  % 第一个节面的滑动角

    % 使用 dsrin 计算第二个节面的参数
    [Ptrpl, Ttrpl, Btrpl, str2_calc, dip2_calc, rake2_calc] = dsrin(str, dip, rake2);

    % 计算第一个节面与给定发震断层的法向夹角
    angle1 = calculate_angle(str, dip, str2, dip2);
    
    % 计算第二个节面与给定发震断层的法向夹角
    angle2 = calculate_angle(str, dip, str2_calc, dip2_calc);
        % 输出当前震源机制法向夹角
    fprintf('第 %d 个震源机制解:\n', i);
    fprintf('夹角 1: %.2f°\n', angle1);
    fprintf('夹角 2: %.2f°\n', angle2);
    
    % 比较两个节面的夹角，选择夹角较小的节面
    if angle1 < angle2
        min_angle = angle1;
        best_str2 = str2;  % 选择第一个节面的走向
        best_dip2 = dip2;  % 选择第一个节面的倾角
        best_rake2 = rake2;  % 选择第一个节面的滑动角
    else
        min_angle = angle2;
        best_str2 = str2_calc;  % 选择第二个节面的走向
        best_dip2 = dip2_calc;  % 选择第二个节面的倾角
        best_rake2 = rake2_calc;  % 选择第二个节面的滑动角
    end
    
    
    % 将最优节面参数存储到 best_node_plane 变量中
    best_node_plane = [best_node_plane; best_str2, best_dip2, best_rake2];
end

% 将最优节面存储为 .txt 文件
writematrix(best_node_plane, 'best_node_plane.txt', 'Delimiter', '\t');