function angle = calculate_angle(str1, dip1, str2, dip2)
    % 计算两个断层面法向量之间的夹角
    % 输入:
    % str1, dip1: 第一个断层面的走向和倾角
    % str2, dip2: 第二个断层面的走向和倾角
    % 输出:
    % angle: 两个法向量的夹角（度）

    % 计算第一个法向量
    n1 = fault_normal(str1, dip1);  % 第一个节面的法向量
    
    % 计算第二个法向量
    n2 = fault_normal(str2, dip2);  % 第二个节面的法向量
     
    % 计算夹角
    angle = acos(dot(n1, n2)) * (180 / pi);  % 转换为度
    
    % 处理点积小于 -1 或大于 1 的情况
    if angle < 0
        angle = 0;
    elseif angle > 180
        angle = 180;
    end
end