function [str,dip,rake]=an2dsr(A,N)
% from A and N to get the strike dip and slip  
% A is silp vector
% N is normal direction
% Coded by Yongge WAN, 2009.5.4
if (N(3)== -1.0) 
  str= atan2(A(2),A(1));
  dip = 0.0;
else
  str = atan2(-N(1),N(2));
  if (N(3)==0.0) 
    dip = 0.5*pi;
  elseif (abs(sin(str))>= 0.1)
    dip = atan2(-N(1)/sin(str),-N(3));
  else
    dip = atan2(N(2)/cos(str),-N(3));
  end
end
a1 = A(1)*cos(str) + A(2)*sin(str);
if (abs(a1)<0.0001) a1 = 0.0; end
if (A(3)~= 0.0) 
  if (dip~= 0.0) 
    rake = atan2(-A(3)/sin(dip),a1);
  else
    rake = atan2(-1000000.0*A(3),a1);
  end
else
  a2 = A(1)*sin(str) - A(2)*cos(str);
  if (abs(a2)< 0.0001) a2 = 0.0;end
  if (abs(sin(2*str))>= 0.0001)
    rake=atan2(a2/sin(2*str),a1);
  elseif (abs(sin(str))>=0.0001) 
    rr=A(2)/sin(str);
    if(rr>1)rr=1.;end
    if(rr<-1)rr=-1.;end
	rake=acos(rr);
 else
  if(a1>1)  a1=1.;end
  if(a1<-1) a1=-1.;end
  rake = acos(a1);
 end 
end 
if (dip<0.0) 
  dip = dip+pi;
  rake = pi-rake;
  if (rake>pi) rake=rake- 2*pi;end
end
if(dip>0.5*pi) 
  dip=pi-dip;
  str=str+pi;
  rake=-rake;
  if (str>=2*pi) str = str - 2*pi;end
end 
if (str<0.0) str=str+2.0*pi;end
str=rad2deg(str);dip=rad2deg(dip);rake=rad2deg(rake);
return